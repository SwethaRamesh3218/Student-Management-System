from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import font,messagebox
from PIL import ImageTk,Image
import pymysql as mysql
from datetime import datetime
#____________________________________________________________________________________________________________________________________________
def open_profile():   
    def fetch_student_details(student_id):
        # Clear the previous student details
        details_label.config(text="")

        # Connect to the database
        connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
        cursor = connection.cursor()

        # Retrieve the details of the specified student from the database
        cursor.execute("SELECT * FROM student_data WHERE StudentID = %s", (student_id,))
        student_data = cursor.fetchone()

        cursor.close()
        connection.close()

        # Display student details
        if student_data:
            details_text = f"Name: {student_data[1]}\n"
            details_text += f"E-mail: {student_data[2]}\n"
            details_text += f"Student ID: {student_data[3]}\n"
            details_text += f"Age: {student_data[4]}\n"
            details_text += f"Date of Birth: {student_data[5]}\n"
            details_text += f"Phone Number: {student_data[6]}\n"
            details_text += f"Address: {student_data[7]}\n"
            details_text += f"Course: {student_data[8]}\n"

            details_label.config(text=details_text)
        else:
            messagebox.showerror("Error", "Student ID not found.")


    # Create the main window
    root = tk.Tk()
    root.title("Student Details")
    root.geometry("950x900")
    root.configure(bg="#84aba5")

    #frame1---------------------------------------------------------------
    frame1=tk.Frame(root,width=950,height=70,bg="#f7076f")
    frame1.place(x=0,y=0)

    f=font.Font(weight="bold",family="Times New Roman",size=30)
    heading=tk.Label(frame1,text='Attendance Management Data',font=f,fg='black',bg="#f7076f")
    heading.place(x=250,y=3)

    f=font.Font(weight="bold",family="Times New Roman",size=20)
    # Create and place widgets
    student_id_label = tk.Label(root, text="Enter Student ID:",font=f,fg='black',bg="#84aba5")
    student_id_label.place(x=200,y=100)

    student_id_entry = tk.Entry(root,font=("Times New Roman",16))
    student_id_entry.place(x=450,y=105)

    f=font.Font(weight="bold",family="Times New Roman",size=10)
    fetch_button = tk.Button(root, text="View Student Details", font=f, fg='black', bg="#0b48e3",
                            command=lambda: fetch_student_details(student_id_entry.get()))
    fetch_button.place(x=380,y=180)

    f=font.Font(weight="bold",family="Times New Roman",size=20)
    details_label = tk.Label(root, text="",font=f)
    details_label.place(x=230,y=350)

#____________________________________________________________________________________________________________________________________
def student_details():
    # Login window
    s_window = Tk()
    s_window.geometry("950x900")
    s_window.title("student detail")
    s_window.configure(bg="#939492")

    #functions
    def create_record():
        def std():
            s1_window = Tk()
            s1_window.geometry("500x500")
            s1_window.title("student detail")
            s1_window.configure(bg="#939492")

            # Create records frame
            frame = tk.Frame(s1_window, width=350, height=450, bg="pink")
            frame.place(x=80, y=15)

            # Create and place labels and entry widgets for registration
            tk.Label(frame, text="Name:", bg="pink", font=("Arial", 12)).place(x=10, y=10)
            name_entry = tk.Entry(frame, font=("Arial", 12))
            name_entry.place(x=150, y=10)

            tk.Label(frame, text="E-mail:", bg="pink", font=("Arial", 12)).place(x=10, y=50)
            email_entry = tk.Entry(frame, font=("Arial", 12))
            email_entry.place(x=150, y=50)

            tk.Label(frame, text="Student ID:", bg="pink", font=("Arial", 12)).place(x=10, y=100)
            student_id_entry = tk.Entry(frame, font=("Arial", 12))
            student_id_entry.place(x=150, y=100)

            tk.Label(frame, text="Age:", bg="pink", font=("Arial", 12)).place(x=10, y=150)
            age_entry = tk.Entry(frame, font=("Arial", 12))
            age_entry.place(x=150, y=150)

            tk.Label(frame, text="DOB(D/M/Y):", bg="pink", font=("Arial", 12)).place(x=10, y=200)
            dob_entry = tk.Entry(frame, font=("Arial", 12))
            dob_entry.place(x=150, y=200)

            tk.Label(frame, text="Phone Number:", bg="pink", font=("Arial", 12)).place(x=10, y=250)
            phone_entry = tk.Entry(frame, font=("Arial", 12))
            phone_entry.place(x=150, y=250)

            tk.Label(frame, text="Address:", bg="pink", font=("Arial", 12)).place(x=10, y=300)
            address_entry = tk.Entry(frame, font=("Arial", 12))
            address_entry.place(x=150, y=300)

            tk.Label(frame, text="Course:", bg="pink", font=("Arial", 12)).place(x=10, y=350)
            course_entry = tk.Entry(frame, font=("Arial", 12))
            course_entry.place(x=150, y=350)

            def con(name_entry, email_entry, student_id_entry, age_entry, dob_entry, phone_entry, address_entry, course_entry):
                # Get values from entry widgets
                name = name_entry.get()
                email = email_entry.get()
                student_id = student_id_entry.get()
                age = age_entry.get()
                dob = dob_entry.get()
                phone = phone_entry.get()
                address = address_entry.get()
                course = course_entry.get()

                # Convert the date format to 'YYYY-MM-DD'
                dob_date = datetime.strptime(dob, "%d/%m/%Y").strftime("%Y-%m-%d")

                connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
                cursor = connection.cursor()

                # Create the table if it doesn't exist
                create_table_query = """
                CREATE TABLE IF NOT EXISTS student_data (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    Name VARCHAR(255),
                    Email VARCHAR(255),
                    StudentID VARCHAR(255),
                    Age INT,
                    DOB VARCHAR(10),
                    Phone VARCHAR(255),
                    Address VARCHAR(255),
                    Course VARCHAR(255)
                )
                """
                cursor.execute(create_table_query)

                # Insert data into the table
                insert_query = """
                INSERT INTO student_data (Name, Email, StudentID, Age, DOB, Phone, Address, Course)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                values = (name, email, student_id, age, dob_date, phone, address, course)
                cursor.execute(insert_query, values)
                connection.commit()
                messagebox.showinfo("Success", "User Inserted Successfully")
                # Clearing entry widgets
                name_entry.delete(0, END)
                email_entry.delete(0, END)
                student_id_entry.delete(0, END)
                age_entry.delete(0, END)
                dob_entry.delete(0, END)
                phone_entry.delete(0, END)
                address_entry.delete(0, END)
                course_entry.delete(0, END)

            # Create and place register button
            register_button = tk.Button(frame, text="Register", font=("Arial", 12), bg="lightgreen", 
                                        command=lambda: con(name_entry, email_entry, student_id_entry, age_entry, dob_entry,
                                                            phone_entry, address_entry, course_entry))
            register_button.place(x=150, y=400)  # Adjusted y-position

            s1_window.mainloop()

        std()


    def delete_record():
        # Get the selected item in the Treeview
        selected_item = tree.selection()
        
        if not selected_item:
            messagebox.showwarning("No Selection", "Please select a record to delete.")
            return
        
        # Get the values of the selected item
        values = tree.item(selected_item, 'values')
        # Assuming the student ID is the third column (index 2), adjust the index if needed
        student_id = values[2]

        # Prompt the user for confirmation
        confirm = messagebox.askyesno("Confirmation", f"Are you sure you want to delete the record with Student ID: {student_id}?")
        
        if confirm:
            # Delete the record from the database
            connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
            cursor = connection.cursor()
            delete_query = "DELETE FROM student_data WHERE StudentID = %s"
            cursor.execute(delete_query, (student_id,))
            connection.commit()
            cursor.close()
            connection.close()

            # Delete the item from the Treeview
            tree.delete(selected_item)

            messagebox.showinfo("Record Deleted", "Student record has been successfully deleted.")

    def update_record():
        # Get the selected item in the Treeview
        selected_item = tree.selection()
        
        if not selected_item:
            messagebox.showwarning("No Selection", "Please select a record to update.")
            return
        
        # Get the values of the selected item
        values = tree.item(selected_item, 'values')
        # Assuming the student ID is the third column (index 2), adjust the index if needed
        student_id = values[2]

        # Create a Toplevel window for updating the record
        update_window = Toplevel(s_window)
        update_window.title("Update Record")
        update_window.geometry("500x500")
        update_window.configure(bg="#96e00b")

        # Create and place labels and entry widgets for updating
        tk.Label(update_window, text="Name:",fg="white",bg="#96e00b").place(x=50, y=20)
        name_entry = tk.Entry(update_window)
        name_entry.place(x=150, y=20)

        tk.Label(update_window, text="E-mail:",fg="white",bg="#96e00b").place(x=50, y=50)
        email_entry = tk.Entry(update_window)
        email_entry.place(x=150, y=50)

        tk.Label(update_window, text="Age:",fg="white",bg="#96e00b").place(x=50, y=80)
        age_entry = tk.Entry(update_window)
        age_entry.place(x=150, y=80)

        tk.Label(update_window, text="DOB(D/M/Y):",fg="white",bg="#96e00b").place(x=50, y=110)
        dob_entry = tk.Entry(update_window)
        dob_entry.place(x=150, y=110)

        tk.Label(update_window, text="Phone Number:",fg="white",bg="#96e00b").place(x=50, y=140)
        phone_entry = tk.Entry(update_window)
        phone_entry.place(x=150, y=140)

        tk.Label(update_window, text="Address:",fg="white",bg="#96e00b").place(x=50, y=170)
        address_entry = tk.Entry(update_window)
        address_entry.place(x=150, y=170)

        tk.Label(update_window, text="Course:",fg="white",bg="#96e00b").place(x=50, y=200)
        course_entry = tk.Entry(update_window)
        course_entry.place(x=150, y=200)

        # Fetch the existing data from the database
        connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
        cursor = connection.cursor()
        cursor.execute("SELECT Name, Email, Age, DOB, Phone, Address, Course FROM student_data WHERE StudentID = %s", (student_id,))
        data = cursor.fetchone()
        cursor.close()
        connection.close()

        # Populate the entry widgets with existing data
        if data:
            name_entry.insert(0, data[0])
            email_entry.insert(0, data[1])
            age_entry.insert(0, data[2])
            dob_entry.insert(0, data[3])
            phone_entry.insert(0, data[4])
            address_entry.insert(0, data[5])
            course_entry.insert(0, data[6])

        def update():
            # Get updated values from entry widgets
            name = name_entry.get()
            email = email_entry.get()
            age = age_entry.get()
            dob = dob_entry.get()
            phone = phone_entry.get()
            address = address_entry.get()
            course = course_entry.get()

            # Update the record in the database
            connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
            cursor = connection.cursor()
            update_query = "UPDATE student_data SET Name=%s, Email=%s, Age=%s, DOB=%s, Phone=%s, Address=%s, Course=%s WHERE StudentID=%s"
            cursor.execute(update_query, (name, email, age, dob, phone, address, course, student_id))
            connection.commit()
            cursor.close()
            connection.close()

            messagebox.showinfo("Success", "Record Updated Successfully")
            # Close the update window
            update_window.destroy()

            # Refresh the Treeview to reflect the changes
            read_file()

        # Create and place update button
        update_button = tk.Button(update_window, text="Update",bg="#040b91",fg="white", command=update)
        update_button.place(x=150, y=230)


    def read_file():
        # Clear existing items in the Treeview
        tree.delete(*tree.get_children())

        # Read data from the database
        connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM student_data")
        data = cursor.fetchall()
        cursor.close()
        connection.close()

        # Insert fetched data into the Treeview
        if data:
            for entry in data:
                tree.insert("", "end", values=entry)
        else:
            tree.insert("", "end", values=("No data found",))

    tree = ttk.Treeview(s_window, columns=("Name", "E-mail","Student ID" "Age", "Date of Birth", "Phone number","Address","Course","Payment"), show="headings")
    tree.heading("#1", text="Name")
    tree.heading("#2", text="E-mail")
    tree.heading("#3", text="Student ID")
    tree.heading("#4", text="Age")
    tree.heading("#5", text="Date of Birth")
    tree.heading("#6", text="phone no")
    tree.heading("#7", text="Address")
    tree.heading("#8", text="Course")
    tree.column("#1", width=100)
    tree.column("#2", width=100)
    tree.column("#3", width=100)
    tree.column("#4", width=100)
    tree.column("#5", width=100)
    tree.column("#6", width=100)
    tree.column("#7", width=100)
    tree.column("#8", width=100)
    tree.place(x=5, y=80, height=650,width=800)

    #frame1---------------------------------------------------------------
    frame1=tk.Frame(s_window,width=950,height=70,bg="#f7076f")
    frame1.place(x=0,y=0)

    f=font.Font(weight="bold",family="Times New Roman",size=30)
    heading=tk.Label(frame1,text='Student Management Data',font=f,fg='black',bg="#f7076f")
    heading.place(x=250,y=3)

    #Buttons frame-------------------------------------------------------------------------------------
    frame=tk.Frame(s_window,width=140,height=800,bg="#1f211e")
    frame.place(x=810,y=80)

    create_button = tk.Button(frame, text="Create", fg="#f00759", bg="#06c9ac",width=20,height=2,command=lambda: create_record())
    create_button.place(x=0, y=0)

    delete_button = tk.Button(frame, text="Delete", fg="#f00759", bg="#06c9ac",width=20,height=2,command=lambda: delete_record())
    delete_button.place(x=0, y=40)

    update_button = tk.Button(frame, text="Update", fg="#f00759", bg="#06c9ac",width=20,height=2,command=lambda: update_record())
    update_button.place(x=0, y=80)

    read_button = tk.Button(frame, text="Read", fg="#f00759", bg="#06c9ac",width=20,height=2,command=lambda: read_file())
    read_button.place(x=0, y=120)

    exit_button = tk.Button(frame, text="Exit", fg="white", bg="#bf060c",width=20,height=2,command=s_window.destroy)
    exit_button.place(x=0, y=160)

#______________________________________________________________________________________________________________________________
def view_records():
    def read_data():
        try:
            # Connect to the database
            connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
            cursor = connection.cursor()

            # Execute SELECT query
            cursor.execute("SELECT * FROM student_attendance")
            
            # Fetch all rows
            data = cursor.fetchall()
            
            # Clear existing data from the tree view
            for item in tree.get_children():
                tree.delete(item)

            # Populate the tree view with fetched data
            for entry in data:
                tree.insert("", "end", values=entry)
            
            cursor.close()
            connection.close()
        except mysql.Error as e:
            # Display error message if there's any exception
            messagebox.showerror("Error", f"Error reading data: {e}")

    # Create the main window
    a2_window = tk.Tk()
    a2_window.geometry("950x900")
    a2_window.title("Student Detail")
    a2_window.configure(bg="#939492")

    # Create a tree view
    tree = ttk.Treeview(a2_window, columns=("S.no", "Student ID", "Name", "Course", "Date", "In Timing", "Out Timing", "Feedback"), show="headings")
    tree.heading("#1", text="S.no")  # Added ID column
    tree.heading("#2", text="Student ID")
    tree.heading("#3", text="Name")
    tree.heading("#4", text="Course")
    tree.heading("#5", text="Date")
    tree.heading("#6", text="In Timing")
    tree.heading("#7", text="Out Timing")
    tree.heading("#8", text="Feedback")

    # Adjust column widths
    for col in tree['columns']:
        tree.column(col, width=100)

    tree.place(x=20, y=80, height=550, width=900)

    #frame1---------------------------------------------------------------
    frame1=tk.Frame(a2_window,width=950,height=70,bg="#f7076f")
    frame1.place(x=0,y=0)

    f=font.Font(weight="bold",family="Times New Roman",size=30)
    heading=tk.Label(frame1,text='Attendance Management Data',font=f,fg='black',bg="#f7076f")
    heading.place(x=250,y=3)

    # Create a button to read data
    read_button = tk.Button(a2_window, text="Read Data", fg="white", bg="blue", width=10, height=2, command=read_data)
    read_button.place(x=300, y=650)
    read_button = tk.Button(a2_window, text="Exit", fg="white", bg="#DC0612", width=10, height=2, command=a2_window.destroy)
    read_button.place(x=600, y=650)

#____________________________________________________________________________________________________________________________
def attendance_page(): 
    def submit(hour_var, minute_var, am_pm_var, out_hour_var, out_minute_var, out_am_pm_var):
        # Get values from entry widgets
        student_id = student_id_entry.get()
        name = name_entry.get()
        course = course_entry.get()
        date = date_entry.get()
        in_timing = f"{hour_var.get()}:{minute_var.get()} {am_pm_var.get()}"
        out_timing = f"{out_hour_var.get()}:{out_minute_var.get()} {out_am_pm_var.get()}"
        feedback = feedback_entry.get("1.0", "end-1c")  # Get feedback from text widget

        # Convert the date format to 'YYYY-MM-DD'
        date_formatted = datetime.strptime(date, "%d/%m/%Y").strftime("%Y-%m-%d")

        # Connect to the database
        connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
        cursor = connection.cursor()

        # Create the table if it doesn't exist
        create_table_query = """
        CREATE TABLE IF NOT EXISTS student_attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            StudentID VARCHAR(10),
            Name VARCHAR(255),
            Course VARCHAR(255),
            Date VARCHAR(10),
            InTiming VARCHAR(10),
            OutTiming VARCHAR(10),
            Feedback TEXT
        )
        """
        cursor.execute(create_table_query)

        # Insert data into the table
        insert_query = """
        INSERT INTO student_attendance (StudentID, Name, Course, Date, InTiming, OutTiming, Feedback)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        values = (student_id, name, course, date_formatted, in_timing, out_timing, feedback)
        cursor.execute(insert_query, values)
        connection.commit()
        messagebox.showinfo("Success", "Attendance Successfully")

        # Clearing entry widgets
        student_id_entry.delete(0, tk.END)
        name_entry.delete(0, tk.END)
        course_entry.delete(0, tk.END)
        date_entry.delete(0, tk.END)
        feedback_entry.delete("1.0", "end")  # Clear text widget content

        cursor.close()
        connection.close()
        a_window.destroy()


    # Login window
    a_window = Tk()
    a_window.geometry("1500x700")
    a_window.title("Attendance")
    a_window.configure(bg="#00A69C")

    #frame-------------------------------------------------------------------
    frame = tk.Frame(a_window, width=600, height=660, bg="#01403e")
    frame.place(x=400, y=25)

    #label,entry,button
    tk.Label(frame, text="Attendance", fg="#ed097f", bg="#01403e", font=("Arial", 23)).place(x=230, y=10)

    tk.Label(frame, text="Name:", bg="#01403e",fg="white", font=("Arial", 15)).place(x=80, y=70)
    name_entry = tk.Entry(frame, font=("Arial", 12))
    name_entry.place(x=310, y=70)

    tk.Label(frame, text="Student ID:", bg="#01403e",fg="white", font=("Arial", 15)).place(x=80, y=120)
    student_id_entry = tk.Entry(frame, font=("Arial", 12))
    student_id_entry.place(x=310, y=120)

    tk.Label(frame, text="Course:", bg="#01403e",fg="white", font=("Arial", 15)).place(x=80, y=170)
    course_entry = tk.Entry(frame, font=("Arial", 12))
    course_entry.place(x=310, y=170)

    tk.Label(frame, text="Date:", bg="#01403e",fg="white", font=("Arial", 15)).place(x=80, y=220)
    date_entry = tk.Entry(frame, font=("Arial", 12))
    date_entry.place(x=310, y=220)

    tk.Label(frame, text="Time", bg="#01403e",fg="white", font=("Arial", 15)).place(x=80, y=280)

    tk.Label(frame, text="In-timing:",bg="#01403e",fg="white", font=("Arial", 15)).place(x=150, y=330)
    hour_var = tk.StringVar()
    hour_combo = tk.OptionMenu(frame, hour_var, *range(1, 13))
    hour_combo.place(x=310, y=330)

    minute_var = tk.StringVar()
    minute_combo = tk.OptionMenu(frame, minute_var, *["00", "05", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60"])
    minute_combo.place(x=370, y=330)

    am_pm_var = tk.StringVar()
    am_pm_combo = tk.OptionMenu(frame, am_pm_var, "AM", "PM")
    am_pm_combo.place(x=450, y=330)

    tk.Label(frame, text="Out-timing:", bg="#01403e",fg="white", font=("Arial", 15)).place(x=150, y=400)
    out_hour_var = tk.StringVar()
    out_hour_combo = tk.OptionMenu(frame, out_hour_var, *range(1, 13))
    out_hour_combo.place(x=310, y=400)

    out_minute_var = tk.StringVar()
    out_minute_combo = tk.OptionMenu(frame, out_minute_var, *["00", "05", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60"])
    out_minute_combo.place(x=370, y=400)

    out_am_pm_var = tk.StringVar()
    out_am_pm_combo = tk.OptionMenu(frame, out_am_pm_var, "AM", "PM")
    out_am_pm_combo.place(x=450, y=400)

    tk.Label(frame, text="Feedback:", bg="#01403e",fg="white", font=("Arial", 15)).place(x=80, y=470)
    feedback_entry = tk.Text(frame, height=5, width=30, font=("Arial", 12))
    feedback_entry.place(x=300, y=470)

    # Create and place buttons for registration
    register_button = tk.Button(frame, text="Submit", font=("Arial", 15), bg="#0dbf16", command=lambda: submit(hour_var, minute_var, am_pm_var, out_hour_var, out_minute_var, out_am_pm_var))
    register_button.place(x=250, y=600)

#________________________________________________________________________________________________________________________
def student_page():
    #window
    main_window1 = tk.Tk()
    main_window1.geometry("1500x1500")
    main_window1.title("Livewire")
    main_window1.configure(bg="#79C2F3")

    #frame1---------------------------------------------------------------
    frame=tk.Frame(main_window1,width=1500,height=100,bg="#1509ed")
    frame.place(x=0,y=0)

    attend_button = tk.Label(frame,text="Attendance Management System",font=("Times New Roman", 50), bg="#1509ed",fg="black")
    attend_button.place(x=270, y=2)

    label = tk.Label(main_window1,text="Welcome to Livewire!",font=("Arial", 30),bg="#79C2F3",fg="black")
    label.place(x=450, y=150)


    #button
    attend_button = tk.Button(main_window1,text="Attendance Submit",font=("Arial", 12),width=20,height=3, bg="#03045e",fg="white",command=attendance_page)
    attend_button.place(x=200, y=350)

    attend_button = tk.Button(main_window1,text="Attendance record",font=("Arial", 12),width=20,height=3, bg="#03045e",fg="white",command=view_records)
    attend_button.place(x=700, y=350)

    attend_button = tk.Button(main_window1,text="Go Back > > >",font=("Times New Roman", 15),width=12,height=2,bg="#e69602",fg="black",command=main_window1.destroy)
    attend_button.place(x=1200, y=590)

#_______________________________________________________________________________________________________________________________________
def admin_page():
    #window
    main_window = tk.Tk()
    main_window.geometry("1500x1500")
    main_window.title("Livewire")
    main_window.configure(bg="#79C2F3")

    #frame1---------------------------------------------------------------
    frame=tk.Frame(main_window,width=1500,height=100,bg="#1509ed")
    frame.place(x=0,y=0)

    attend_button = tk.Label(frame,text="Students Mangement System",font=("Times New Roman", 50), bg="#1509ed",fg="black")
    attend_button.place(x=270, y=2)

    label = tk.Label(main_window,text="Welcome to Livewire!",font=("Arial", 30),bg="#79C2F3",fg="black")
    label.place(x=450, y=150)


    #button
    attend_button = tk.Button(main_window,text="Attendance Records",font=("Arial", 12),width=20,height=3, bg="#03045e",fg="white",command=view_records)
    attend_button.place(x=100, y=350)

    attend_button = tk.Button(main_window,text="Student Details",font=("Arial", 12),width=20,height=3, bg="#03045e",fg="white",command=student_details)
    attend_button.place(x=560, y=350)

    attend_button = tk.Button(main_window,text="Open Profile",font=("Arial", 12),width=20,height=3, bg="#03045e",fg="white",command=open_profile)
    attend_button.place(x=1000, y=350)

    attend_button = tk.Button(main_window,text="Go Back > > >",font=("Times New Roman", 15),width=12,height=2,bg="#e69602",fg="black",command=main_window.destroy)
    attend_button.place(x=1200, y=590)

#___________________________________________________________________________________________________________________________________
def student_login():
    def validate_login(username, password):
        # Connect to the database
        connection = mysql.connect(host="localhost", user="root", password="swetha", database="attendance")
        cursor = connection.cursor()

        # Query the database to retrieve StudentID based on email and student ID
        cursor.execute("SELECT StudentID FROM student_data WHERE Email = %s AND StudentID = %s", (username, password))
        result = cursor.fetchone()

        cursor.close()
        connection.close()

        # If a StudentID is found, return True indicating successful login, otherwise return False
        if result is not None:
            return True
        else:
            return False


    def login():
        username = username_entry.get()
        password = password_entry.get()

        if validate_login(username, password):
            login_window.destroy()
            student_page()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    login_window = Tk()
    login_window.geometry("1500x1500")
    login_window.title("Login")
    login_window.configure(bg="#07aaeb")

    #frame
    frame=Frame(login_window,width=500,height=380,bg="#FFFFFF")
    frame.place(x=450,y=180)

    f=font.Font(weight="bold",family="Times New Roman",size=20)
    heading=Label(frame,text='Student login',font=f,fg='black',bg="#FFFFFF")
    heading.place(x=180,y=20)

    #username----------------------------------------------------------------#
    def on_enter(e):
        username_entry.delete(0, 'end')

    def on_leave(e):
        name = username_entry.get()
        if name=='':
            username_entry.insert(0,'username')

    username_entry= Entry(frame,width=25,fg='black',border=0,bg="#FFFFFF")
    username_entry.place(x=80,y=90)
    username_entry.insert(0,'username')
    username_entry.bind('<FocusIn>', on_enter)
    username_entry.bind('<FocusOut>', on_leave)

    Frame(frame,width=345,height=2,bg="black").place(x=75,y=125)

    #password---------------------------------------------------------------------#
    def on_enter(e):
        password_entry.delete(0, 'end')

    def on_leave(e):
        name = password_entry.get()
        if name=='':
            password_entry.insert(0,'password')

    password_entry = Entry(frame,width=25,fg='black',border=0,bg="#FFFFFF")
    password_entry.place(x=80,y=180)
    password_entry.insert(0,'password')
    password_entry.bind('<FocusIn>', on_enter)
    password_entry.bind('<FocusOut>', on_leave)

    Frame(frame,width=345,height=2,bg="black").place(x=75,y=215)

    #Button--------------------------------------------------------------------#

    Button(frame,width=15,height=2,pady=1,text='Login',bg="#0740eb",fg="white",border=0,command=login).place(x=80,y=280)
    Button(frame,width=15,height=2,pady=1,text='Cancel',bg="#e69602",fg="white",border=0,command=login_window.destroy).place(x=290,y=280)
#_______________________________________________________________________________________________________________________
def admin_login():
    # login page for attendence
    def check_login():
        username = username_entry.get()
        password = password_entry.get()

        # Check if username and password match
        if username == "livewire" and password == "3218":
            login_window.destroy()
            admin_page()
        else:
            messagebox.showerror("Error", "Invalid username or password")

    # Login window
    login_window = Tk()
    login_window.geometry("1500x1500")
    login_window.title("Login")
    login_window.configure(bg="#259777")

    #frame
    frame=Frame(login_window,width=500,height=380,bg="#FFFFFF")
    frame.place(x=450,y=180)

    f=font.Font(weight="bold",family="Times New Roman",size=20)
    heading=Label(frame,text='Admin login',font=f,fg='black',bg="#FFFFFF")
    heading.place(x=180,y=20)

    #username----------------------------------------------------------------#
    def on_enter(e):
        username_entry.delete(0, 'end')

    def on_leave(e):
        name = username_entry.get()
        if name=='':
            username_entry.insert(0,'username')

    username_entry= Entry(frame,width=25,fg='black',border=0,bg="#FFFFFF")
    username_entry.place(x=80,y=90)
    username_entry.insert(0,'username')
    username_entry.bind('<FocusIn>', on_enter)
    username_entry.bind('<FocusOut>', on_leave)

    Frame(frame,width=345,height=2,bg="black").place(x=75,y=125)

    #password---------------------------------------------------------------------#
    def on_enter(e):
        password_entry.delete(0, 'end')

    def on_leave(e):
        name = password_entry.get()
        if name=='':
            password_entry.insert(0,'password')

    password_entry = Entry(frame,width=25,fg='black',border=0,bg="#FFFFFF")
    password_entry.place(x=80,y=180)
    password_entry.insert(0,'password')
    password_entry.bind('<FocusIn>', on_enter)
    password_entry.bind('<FocusOut>', on_leave)

    Frame(frame,width=345,height=2,bg="black").place(x=75,y=215)

    #Button--------------------------------------------------------------------#

    Button(frame,width=15,height=2,pady=1,text='Login',bg="#12A65A",fg="white",border=0,command=check_login).place(x=80,y=280)
    Button(frame,width=15,height=2,pady=1,text='Cancel',bg="#e69602",fg="white",border=0,command=login_window.destroy).place(x=290,y=280)
#______________________________________________________________________________________________________________________________________    
def Home():
    # Login window
    screen = Tk()
    screen.geometry("1500x1500")
    screen.title("Login")
    screen.configure(bg="#05ad9a")

    #image
    img = Image.open("logo.jpg")
    img = img.resize((1450,160))
    img = ImageTk.PhotoImage(img)
    Label(screen,image=img).pack()

    #text
    f=font.Font(weight="bold",family="Times New Roman",size=15)
    t="""Livewire represents an electrifying blend of high-end skills,expert trainers, and individual attention. Our goal as a
    part of CADD Centre,a global skill development conglomerate, is to bring these three factors together and prepare you, 
    the students, for exciting careers in emerging technologies.Our courses are created by product 
    developers and industry experts. Expert trainers deliver training in our modern and digital classroom environments and 
    industry-grade labs. The training is based on immersive learning and takes advantage of the benefits of hybrid teaching 
    to improve skill development outcomes."""
    l=Label(screen,text=t,bg="#05ad9a",font=f).place(relx=.12,rely=.35)

    #image
    img1 = Image.open("student.jpg")
    img1 = img1.resize((120,120))
    img1 = ImageTk.PhotoImage(img1)
    Button(screen,image=img1,command=student_login).place(relx=.18,rely=.70)

    img2 = Image.open("admin.jpg")
    img2 = img2.resize((120,120))
    img2 = ImageTk.PhotoImage(img2)
    Button(screen,image=img2,command=admin_login).place(relx=.43,rely=.70)

    img3 = Image.open("exit.jpg")
    img3 = img3.resize((120,120))
    img3 = ImageTk.PhotoImage(img3)
    Button(screen,image=img3,command=screen.destroy).place(relx=.68,rely=.70)

    screen.mainloop()

Home()
